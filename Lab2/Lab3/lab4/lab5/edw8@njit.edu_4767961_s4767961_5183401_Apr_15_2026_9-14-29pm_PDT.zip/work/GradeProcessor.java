import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class GradeProcessor {

    public static void main(String[] args) {

        // Input and Output file names
        String inputFileName = "student_data.txt";
        String outputFileName = "grade_report.txt";

        // TODO 1: Wrap your code in a try-catch block
        try {

            // TODO 2: Create a File object and Scanner to read the input file
            File inputFile = new File(inputFileName);
            Scanner input = new Scanner(inputFile);

            // TODO 3: Create a PrintWriter to write to the output file
            PrintWriter output = new PrintWriter(outputFileName);

            System.out.println("Processing file...");

            // Write header to output file
            output.println("Name\tAverage\tStatus");
            output.println("-----------------------------");

            // TODO 4: Process the file line by line
            while (input.hasNext()) {

                // Read name and scores
                String name = input.next();
                double score1 = input.nextDouble();
                double score2 = input.nextDouble();
                double score3 = input.nextDouble();

                // Calculate average
                double average = (score1 + score2 + score3) / 3;

                // Determine Pass or Fail
                String result;
                if (average >= 70.0) {
                    result = "Pass";
                } else {
                    result = "Fail";
                }

                // Write formatted output to file
                output.printf("%s\t%.2f\t%s%n", name, average, result);
            }

            // TODO 5: Close Scanner and PrintWriter
            input.close();
            output.close();

            System.out.println("Done! Check " + outputFileName + " for results.");

        }

        // TODO 6: Catch block
        catch (FileNotFoundException e) {
            System.out.println("Error: File not found.");
        }
    }
}