public abstract class BankAccount {
    private String accountHolder;
    private double balance;

public abstract class BankAccount {

    // --- INSTANCE VARIABLES ---
    private String accountHolder;
    private double balance;

    // --- CONSTRUCTOR ---
    public BankAccount(String accountHolder, double initialDeposit) {
        // Initialize the instance variables
        this.accountHolder = accountHolder;

        if (initialDeposit < 0) {
            // Do not allow a negative starting balance
            this.balance = 0.0;
        } else {
            this.balance = initialDeposit;
        }
    }

    // --- METHODS ---

    public void deposit(double amount) {
        // Implement deposit logic and error handling for incorrect input
        if (amount <= 0) {
            System.out.println("Deposit amount must be positive.");
            return;
        }

        balance += amount;
    }

    // Abstract method: child classes must implement this.
    public abstract void withdraw(double amount);

    // --- GETTERS AND SETTERS ---

    public String getAccountHolder() {
        // Return the account holder name
        return accountHolder;
    }

    public double getBalance() {
        // Return the current balance
        return balance;
    }

    protected void setBalance(double balance) {
        // Set the balance (used by child classes)
        this.balance = balance;
    }
}
    