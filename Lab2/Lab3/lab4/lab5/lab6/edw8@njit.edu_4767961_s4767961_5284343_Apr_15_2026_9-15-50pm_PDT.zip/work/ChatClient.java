import java.net.*;
import java.util.Scanner;
import java.io.*;

/* ChatClient.java
 * A simple client program that connects to a server, and then
 * exchanges messages with the server until either side sends "quit"
 * (or an error occurs).
 */
class ChatClient {

    public static void main(String[] args) {

        String ipAddress;
        int port = 1728;

        Socket connection = null;

        BufferedReader incoming = null;
        PrintWriter outgoing = null;
        String messageOut;
        String messageIn;

        Scanner userInput = new Scanner(System.in);

        // 1. Get the IP address or domain name of the server from the user.
        System.out.print("Enter server IP or hostname: ");
        ipAddress = userInput.nextLine();

        // 2. Request connection to server on specified host and port
        try {
            System.out.println("Connecting to " + ipAddress + " on port " + port);
            connection = new Socket(ipAddress, port);
            System.out.println("Connected. Enter your first message.");
        }
        catch (Exception e) {
            System.out.println("Connection failed: " + e.getMessage());
            userInput.close();
            return;
        }

        // 3. Exchange messages with the server.
        try {
            incoming = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            outgoing = new PrintWriter(connection.getOutputStream(), true);

            System.out.println("NOTE: Enter 'quit' to end the program.\n");

            while (true) {
                System.out.print("SEND:      ");
                messageOut = userInput.nextLine();
                outgoing.println(messageOut);

                if (messageOut.equalsIgnoreCase("quit")) {
                    System.out.println("Connection closed.");
                    break;
                }

                if (outgoing.checkError()) {
                    throw new IOException("Error occurred while transmitting message.");
                }

                System.out.println("WAITING...");
                messageIn = incoming.readLine();

                if (messageIn == null) {
                    System.out.println("Server disconnected.");
                    break;
                }

                System.out.println("RECEIVED:  " + messageIn);

                if (messageIn.equalsIgnoreCase("quit")) {
                    System.out.println("Connection closed.");
                    break;
                }
            }
        }
        catch (Exception e) {
            System.out.println("Error during communication: " + e.getMessage());
        }
        finally {
            userInput.close();

            try {
                if (incoming != null) {
                    incoming.close();
                }
            } catch (Exception e) {
            }

            try {
                if (outgoing != null) {
                    outgoing.close();
                }
            } catch (Exception e) {
            }

            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (Exception e) {
            }
        }
    }
}